"use strict";
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const P=(window.Capacitor&&window.Capacitor.Plugins)||{};
const LS=(k,d)=>{try{const v=JSON.parse(localStorage.getItem(k));return v==null?d:v}catch{return d}};
const store=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
const mkErr=(m,s,f)=>{const e=new Error(m);e.status=s;e.fatal=!!f;return e};
const clean=t=>t.replace(/```json|```/g,"").trim();
const b64ToBytes=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));

const TPL={
"Tarix illustratsiya":"hand-painted historical illustration, aged parchment textures, warm sepia palette, ink and watercolor, cinematic composition",
"Tarix":"epic cinematic historical scene, realistic oil-painting look, dramatic lighting, rich detail",
"Qadimgi odamlar":"simple funny stickman cartoon characters with big expressive eyes, colorful flat background, comic style",
"Biznes":"clean modern illustration, realistic storefronts and city, bright colors, infographic feel",
"Omon qolish":"stylized cartoon characters in dramatic survival scenes, vivid colors, high contrast",
"Ong va falsafa":"minimal dark moody illustration, lone white round-headed stick figure, soft lamp light, rainy window",
"G'alati tarix":"quirky colorful cartoon history, funny characters, bold outlines, saturated colors",
"Realizm":"photorealistic, natural lighting, ultra detailed, 35mm photo"};
const VOICES=["Kore","Puck","Charon","Fenrir","Aoede","Zephyr","Leda","Orus"];
const LANGS={uz:["O'zbek","uz"],ru:["Rus","ru"],en:["Ingliz","en"],tr:["Turk","tr"]};
const NAMES=["Mavzu","Ssenariy","Ovoz","Kadrlar","Montaj","Eksport","SEO"];

let SET=Object.assign({keys:[],textModel:"gemini-2.5-flash",imgModel:"gemini-2.5-flash-image",ttsModel:"gemini-2.5-flash-preview-tts",engine:"translate",voice:"Kore",subs:true},LS("vg_set",{}));
let S=Object.assign({topic:"",tpl:"Tarix illustratsiya",min:8,tone:"Hikoya",lang:"uz",scenes:[],title:"",seo:null},LS("vg_state",{}));
const HAVE={aud:new Set(),img:new Set()};
let CANCEL=false,busy=false,OUT=null,OUTEXT="webm";
const saveS=()=>store("vg_state",S),saveSet=()=>store("vg_set",SET);

/* ---------- IndexedDB ---------- */
const DB={d:null,open(){return this.d||(this.d=new Promise((res,rej)=>{const r=indexedDB.open("vg",1);r.onupgradeneeded=()=>r.result.createObjectStore("kv");r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)}))},
async tx(m,f){const d=await this.open();return new Promise((res,rej)=>{const t=d.transaction("kv",m);const o=f(t.objectStore("kv"));t.oncomplete=()=>res(o.result);t.onerror=()=>rej(t.error)})},
get(k){return this.tx("readonly",s=>s.get(k))},set(k,v){return this.tx("readwrite",s=>s.put(v,k))},keys(){return this.tx("readonly",s=>s.getAllKeys())},clear(){return this.tx("readwrite",s=>s.clear())}};
async function loadHave(){HAVE.aud.clear();HAVE.img.clear();for(const k of await DB.keys()){const[t,i]=String(k).split(":");if(HAVE[t])HAVE[t].add(+i)}}

/* ---------- UI helpers ---------- */
const status=t=>$("#status").textContent=t,setProg=p=>$("#prog i").style.width=Math.round(p*100)+"%";
async function run(fn){if(busy)return status("Boshqa jarayon ketmoqda…");busy=true;CANCEL=false;$("#stop").style.display="block";
 try{await fn()}catch(e){status("❌ "+e.message)}finally{busy=false;$("#stop").style.display="none"}}
$("#stop").onclick=()=>{CANCEL=true;status("To'xtatilmoqda…")};
function go(i){$$(".step").forEach((e,k)=>e.classList.toggle("on",k===i));$$("#tabs a").forEach((e,k)=>e.classList.toggle("on",k===i));
 $("#ttl").textContent=i<7?NAMES[i]:"Sozlamalar";$("#cnt").textContent=i<7?`${i+1} / 7`:"";scrollTo(0,0);
 if(i===1)drawScenes();if(i===2)drawAud();if(i===3)drawGrid();if(i===7)drawSettings()}
$("#tabs").innerHTML=NAMES.map((n,i)=>`<a data-i="${i}">${n}</a>`).join("");
$("#tabs").onclick=e=>e.target.dataset.i&&go(+e.target.dataset.i);
$("#gear").onclick=()=>go(7);
const opts=(el,arr,val)=>{el.innerHTML=arr.map(([v,l])=>`<option value="${v}" ${v==val?"selected":""}>${l}</option>`).join("")};

/* ---------- API key pool (rotation) ---------- */
const Pool={i:0,st:{},
async call(fn){let tries=0;
 for(;;){
  if(CANCEL)throw new Error("To'xtatildi");
  const all=SET.keys;if(!all.length)throw mkErr("Sozlamalardan Gemini API key qo'shing",0,true);
  const now=Date.now(),alive=all.filter(k=>!(this.st[k]||{}).dead);
  if(!alive.length)throw mkErr("Barcha keylar yaroqsiz",0,true);
  const ok=alive.filter(k=>((this.st[k]||{}).until||0)<=now);
  if(!ok.length){const w=Math.min(...alive.map(k=>this.st[k].until))-now;
   if(w>15*60e3)throw mkErr("Barcha keylar kunlik limitda. Keyinroq urinib ko'ring yoki yangi key qo'shing",429,true);
   for(let s=Math.ceil(w/1000);s>0&&!CANCEL;s--){status(`⏳ Keylar limitda, ${s}s kutilmoqda…`);await sleep(1000)}continue}
  const k=ok[this.i++%ok.length],n=all.indexOf(k)+1,st=this.st[k]=this.st[k]||{};
  try{return await fn(k)}catch(e){const m=e.message||"",s=e.status;
   if(/limit:\s*0/.test(m))throw mkErr("Bu model uchun bepul limit 0 (to'lovli reja kerak yoki boshqa model tanlang)",429,true);
   if(s==429||/quota|exhausted/i.test(m)){st.until=Date.now()+(/per ?day/i.test(m)?6*3600e3:65e3);status(`🔁 Key #${n} limit — keyingisiga o'tildi`)}
   else if((s==400&&/API key not valid|API_KEY_INVALID/i.test(m))||s==401||s==403){st.dead=true;status(`❌ Key #${n} yaroqsiz`)}
   else if(!s||s>=500){if(++tries>6)throw e;st.until=Date.now()+2500*tries;await sleep(1500)}
   else throw e}
 }}};

async function gem(model,body,key){
 const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,{method:"POST",headers:{"Content-Type":"application/json","x-goog-api-key":key},body:JSON.stringify(body)});
 const j=await r.json().catch(()=>({}));
 if(!r.ok)throw mkErr(j.error&&j.error.message||r.statusText,r.status);
 return j}
const parts=j=>((j.candidates||[])[0]||{}).content?.parts||[];
async function genText(prompt,json){
 return Pool.call(async k=>{const j=await gem(SET.textModel,{contents:[{parts:[{text:prompt}]}],generationConfig:json?{responseMimeType:"application/json",maxOutputTokens:32768}:{}},k);
  const t=parts(j).map(p=>p.text||"").join("");if(!t)throw mkErr("Bo'sh javob",502);return t})}
async function genJSON(prompt){let err;for(let i=0;i<3;i++){try{return JSON.parse(clean(await genText(prompt,true)))}catch(e){err=e;if(e.fatal||CANCEL)throw e}}throw err}

/* ---------- Step 0: topic ---------- */
function initTopic(){
 $("#topic").value=S.topic;$("#topic").oninput=e=>{S.topic=e.target.value;saveS()};
 const drawT=()=>{$("#tpls").innerHTML=Object.keys(TPL).map(n=>`<span class="chip ${n==S.tpl?"on":""}" data-n="${n}">${n}</span>`).join("")};drawT();
 $("#tpls").onclick=e=>{if(e.target.dataset.n){S.tpl=e.target.dataset.n;saveS();drawT()}};
 opts($("#min"),[3,5,8,10,15,20].map(m=>[m,m+" daqiqa"]),S.min);opts($("#lang"),Object.entries(LANGS).map(([k,v])=>[k,v[0]]),S.lang);
 opts($("#tone"),["Hikoya","Jiddiy","Hazil","Dramatik","Ilmiy-ommabop"].map(x=>[x,x]),S.tone);
 $("#min").onchange=e=>{S.min=+e.target.value;saveS()};$("#lang").onchange=e=>{S.lang=e.target.value;saveS()};$("#tone").onchange=e=>{S.tone=e.target.value;saveS()};
 $("#idea").onclick=()=>run(async()=>{status("G'oyalar izlanmoqda…");
  const j=await genJSON(`YouTube uchun "${S.tpl}" uslubidagi ${LANGS[S.lang][0]} tilida 10 ta virusga aylanishi mumkin bo'lgan, qiziqarli video mavzu taklif qil${S.topic?` (yo'nalish: ${S.topic})`:""}. Faqat JSON: {"ideas":["",...]}`);
  $("#ideas").innerHTML=j.ideas.map(x=>`<span class="chip">${x}</span>`).join("");status("Mavzuni tanlang")});
 $("#ideas").onclick=e=>{if(e.target.classList.contains("chip")){S.topic=e.target.textContent;$("#topic").value=S.topic;saveS()}};
 $("#to1").onclick=()=>{if(!S.topic.trim())return status("Mavzu yozing");go(1);if(!S.scenes.length)$("#genScript").click()};
}

/* ---------- Step 1: script ---------- */
function drawScenes(){$("#sinfo").textContent=S.scenes.length?`${S.title} — ${S.scenes.length} sahna`:"Hali ssenariy yo'q";
 $("#scenes").innerHTML=S.scenes.map((s,i)=>`<div class="sc"><small>Kadr ${i+1}</small><textarea data-i="${i}" data-k="text" rows="2">${s.text}</textarea><textarea data-i="${i}" data-k="prompt" rows="2">${s.prompt}</textarea></div>`).join("")}
$("#scenes").oninput=e=>{const d=e.target.dataset;if(d.i){S.scenes[d.i][d.k]=e.target.value;saveS();if(d.k=="text")HAVE.aud.delete(+d.i);if(d.k=="prompt")HAVE.img.delete(+d.i)}};
$("#genScript").onclick=()=>run(async()=>{
 const n=Math.round(S.min*60/4.5),L=LANGS[S.lang][0],style=TPL[S.tpl];status("Reja tuzilmoqda…");
 const plan=await genJSON(`Sen YouTube ssenariychisan. Mavzu: "${S.topic}". Ohang: ${S.tone}. Uzunlik: ${S.min} daqiqa. ${L} tilida jozibali video sarlavha va ${Math.max(6,Math.round(S.min*1.2))} bandli reja tuz. Faqat JSON: {"title":"","outline":[""]}`);
 S.title=plan.title;const out=[];
 for(let from=0;from<n;from+=25){const to=Math.min(n,from+25),prev=out.slice(-3).map(s=>s.text).join(" ");
  const j=await genJSON(`Video: "${S.title}". Mavzu: ${S.topic}. Ohang: ${S.tone}. Reja: ${plan.outline.join(" | ")}. Jami ${n} sahna; hozir ${from+1}–${to} sahnalarni yoz (${to-from} ta). Oldingi matn oxiri: "${prev}". Har sahna: "narration" — ${L} tilida 1–2 gap (10–14 so'z), faktlarga asoslangan, ravon, takrorlama${from==0?", birinchi sahna qiziqarli hook bo'lsin":""}${to==n?", oxirgi sahna xulosa va obunaga chaqiriq":""}; "prompt" — ingliz tilida kadr tasviri (yozuvsiz). Uslub: ${style}. Faqat JSON: {"scenes":[{"narration":"","prompt":""}]}`);
  out.push(...(j.scenes||j).map(s=>({text:s.narration,prompt:s.prompt})));setProg(to/n);status(`Ssenariy: ${out.length}/${n}`)}
 S.scenes=out;S.seo=null;saveS();await DB.clear();await loadHave();drawScenes();status("✅ Ssenariy tayyor");setProg(0)});
$("#to2").onclick=()=>go(2);

/* ---------- Step 2: voice ---------- */
let _ac;const AC=()=>_ac||(_ac=new (window.AudioContext||window.webkitAudioContext)({sampleRate:24000}));
function pcmWav(pcm,rate){const b=new ArrayBuffer(44+pcm.length*2),v=new DataView(b),w=(o,s)=>[...s].forEach((c,i)=>v.setUint8(o+i,c.charCodeAt(0)));
 w(0,"RIFF");v.setUint32(4,36+pcm.length*2,true);w(8,"WAVEfmt ");v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,1,true);v.setUint32(24,rate,true);v.setUint32(28,rate*2,true);v.setUint16(32,2,true);v.setUint16(34,16,true);w(36,"data");v.setUint32(40,pcm.length*2,true);
 new Int16Array(b,44).set(pcm);return new Blob([b],{type:"audio/wav"})}
function bufsWav(bufs){const rate=bufs[0].sampleRate,gap=Math.round(rate*.12);let len=0;bufs.forEach(b=>len+=b.length+gap);
 const pcm=new Int16Array(len);let o=0;for(const b of bufs){const d=b.getChannelData(0);for(let i=0;i<d.length;i++)pcm[o++]=Math.max(-1,Math.min(1,d[i]))*32767;o+=gap}return pcmWav(pcm,rate)}
function splitText(t,max){const out=[];let cur="";for(const w of t.split(/(?<=[.!?,;:])\s+|\s+/)){if((cur+" "+w).trim().length>max){out.push(cur.trim());cur=w}else cur+=" "+w}if(cur.trim())out.push(cur.trim());return out}
async function ttsTranslate(text){
 const bufs=[];
 for(const p of splitText(text,180)){const url=`https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=${LANGS[S.lang][1]}&q=${encodeURIComponent(p)}`;
  let ab,err;for(let t=0;t<3;t++){try{
    if(P.CapacitorHttp){const r=await P.CapacitorHttp.get({url,responseType:"blob"});if(r.status!==200)throw mkErr("Google TTS: "+r.status,r.status);ab=b64ToBytes(r.data).buffer}
    else{const r=await fetch(url);if(!r.ok)throw mkErr("Google TTS: "+r.status,r.status);ab=await r.arrayBuffer()}
    bufs.push(await AC().decodeAudioData(ab));err=null;break}catch(e){err=e;await sleep(800*(t+1))}}
  if(err)throw err}
 return bufsWav(bufs)}
async function ttsGemini(text){
 const j=await Pool.call(k=>gem(SET.ttsModel,{contents:[{parts:[{text}]}],generationConfig:{responseModalities:["AUDIO"],speechConfig:{voiceConfig:{prebuiltVoiceConfig:{voiceName:SET.voice}}}}},k));
 const p=parts(j).find(p=>p.inlineData||p.inline_data);if(!p)throw mkErr("Ovoz qaytmadi",502);
 const b=b64ToBytes((p.inlineData||p.inline_data).data);return pcmWav(new Int16Array(b.buffer,0,b.length>>1),24000)}
async function ttsOne(t){if(SET.engine==="translate")return ttsTranslate(t);
 try{return await ttsGemini(t)}catch(e){if(SET.engine==="auto"&&!CANCEL)return ttsTranslate(t);throw e}}
function drawAud(){opts($("#engine"),[["translate","Google Translate (bepul)"],["gemini","Gemini TTS"],["auto","Gemini → Translate (zaxira)"]],SET.engine);
 opts($("#voice"),VOICES.map(v=>[v,v]),SET.voice);$("#ainfo").textContent=`Tayyor: ${HAVE.aud.size}/${S.scenes.length}`}
$("#engine").onchange=e=>{SET.engine=e.target.value;saveSet()};$("#voice").onchange=e=>{SET.voice=e.target.value;saveSet()};
$("#testAud").onclick=()=>run(async()=>{if(!S.scenes.length)throw new Error("Avval ssenariy");status("Sinov…");const b=await ttsOne(S.scenes[0].text);await new Audio(URL.createObjectURL(b)).play();status("✅")});
$("#genAud").onclick=()=>run(async()=>{
 const n=S.scenes.length,todo=[...Array(n).keys()].filter(i=>!HAVE.aud.has(i));let p=0,done=0,err=0;
 const worker=async()=>{while(p<todo.length&&!CANCEL){const i=todo[p++];
  try{await DB.set("aud:"+i,await ttsOne(S.scenes[i].text));HAVE.aud.add(i)}catch(e){if(e.fatal||CANCEL)throw e;err++}
  setProg(++done/todo.length);status(`Ovoz: ${HAVE.aud.size}/${n}`)}};
 await Promise.all(Array(SET.engine==="gemini"?1:3).fill(0).map(worker));drawAud();
 status(HAVE.aud.size==n?"✅ Barcha ovozlar tayyor":`Ovoz: ${HAVE.aud.size}/${n}, xato: ${err}. Qayta bosing — davom etadi`);setProg(0)});

/* ---------- Step 3: frames ---------- */
let URLS=[];
async function drawGrid(){URLS.forEach(URL.revokeObjectURL);URLS=[];let h="";
 for(const i of [...HAVE.img].sort((a,b)=>a-b).slice(0,60)){const b=await DB.get("img:"+i);if(b){const u=URL.createObjectURL(b);URLS.push(u);h+=`<img src="${u}">`}}
 $("#grid").innerHTML=h;$("#iinfo").textContent=`Tayyor: ${HAVE.img.size}/${S.scenes.length}`}
async function imgOne(i){const s=S.scenes[i];
 const j=await Pool.call(k=>gem(SET.imgModel,{contents:[{parts:[{text:`${s.prompt}. Style: ${TPL[S.tpl]}. 16:9 widescreen, no text, no watermark.`}]}],generationConfig:{responseModalities:["IMAGE","TEXT"],imageConfig:{aspectRatio:"16:9"}}},k));
 const p=parts(j).find(p=>p.inlineData||p.inline_data);if(!p)throw mkErr("Rasm qaytmadi",422);
 const d=p.inlineData||p.inline_data;return new Blob([b64ToBytes(d.data)],{type:d.mimeType||"image/png"})}
$("#genImg").onclick=()=>run(async()=>{
 const n=S.scenes.length,todo=[...Array(n).keys()].filter(i=>!HAVE.img.has(i));let p=0,done=0,err=0;
 const worker=async()=>{while(p<todo.length&&!CANCEL){const i=todo[p++];
  try{await DB.set("img:"+i,await imgOne(i));HAVE.img.add(i)}catch(e){if(e.fatal||CANCEL)throw e;err++}
  setProg(++done/todo.length);status(`Kadr: ${HAVE.img.size}/${n}`)}};
 await Promise.all([worker(),worker()]);await drawGrid();
 status(HAVE.img.size==n?"✅ Barcha kadrlar tayyor":`Kadr: ${HAVE.img.size}/${n}, xato: ${err}. Qayta bosing (yetmaganlari rangli fon bilan chiqadi)`);setProg(0)});

/* ---------- Step 4: render ---------- */
const pickMime=()=>["video/mp4;codecs=avc1.42E01E,mp4a.40.2","video/webm;codecs=vp8,opus","video/webm;codecs=vp9,opus","video/webm"].find(m=>MediaRecorder.isTypeSupported(m));
const fmt=t=>`${Math.floor(t/60)}:${String(Math.floor(t%60)).padStart(2,"0")}`;
function wrap(g,t,w){const L=[];let c="";for(const x of t.split(" ")){if(g.measureText(c+" "+x).width>w){L.push(c);c=x}else c=(c+" "+x).trim()}L.push(c);return L}
$("#subs").checked=SET.subs;$("#subs").onchange=e=>{SET.subs=e.target.checked;saveSet()};
$("#render").onclick=()=>run(async()=>{
 const n=S.scenes.length;if(!n)throw new Error("Ssenariy yo'q");
 const ctx=AC();await ctx.resume();const bufs=[];
 for(let i=0;i<n;i++){status(`Ovoz yuklanmoqda ${i+1}/${n}`);const b=await DB.get("aud:"+i);if(!b)throw new Error(`${i+1}-kadr ovozi yo'q. Ovoz bosqichini tugating`);bufs.push(await ctx.decodeAudioData(await b.arrayBuffer()))}
 const starts=[],pad=.35;let total=0;bufs.forEach(b=>{starts.push(total);total+=b.duration+pad});
 const cv=$("#cv"),g=cv.getContext("2d"),W=1280,H=720;
 const dest=ctx.createMediaStreamDestination(),stream=cv.captureStream(30);dest.stream.getAudioTracks().forEach(t=>stream.addTrack(t));
 const mime=pickMime(),rec=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:5e6,audioBitsPerSecond:128e3}),chunks=[];
 rec.ondataavailable=e=>e.data.size&&chunks.push(e.data);const stopped=new Promise(r=>rec.onstop=r);
 const ready={},pend={};const load=i=>{if(i>=n||i in pend)return pend[i];return pend[i]=DB.get("img:"+i).then(b=>b?createImageBitmap(b):null).then(x=>ready[i]=x)};
 await load(0);load(1);let wl;try{wl=await navigator.wakeLock.request("screen")}catch{}
 const draw=(i,p,a)=>{const b=ready[i];g.globalAlpha=a;
  if(b){const z=i%2?1.12-.1*p:1.02+.1*p,r=Math.max(W/b.width,H/b.height)*z,w=b.width*r,h=b.height*r;g.drawImage(b,(W-w)/2+(i%3-1)*25*(p-.5),(H-h)/2,w,h)}
  else{const gr=g.createLinearGradient(0,0,W,H);gr.addColorStop(0,"#2a1b4d");gr.addColorStop(1,"#0e0b1a");g.fillStyle=gr;g.fillRect(0,0,W,H)}g.globalAlpha=1};
 rec.start(1000);const t0=ctx.currentTime+.3;
 bufs.forEach((b,i)=>{const s=ctx.createBufferSource();s.buffer=b;s.connect(dest);s.start(t0+starts[i])});
 let cur=0;
 await new Promise(res=>{const tick=()=>{
  if(CANCEL)return res();const t=ctx.currentTime-t0;if(t>=total)return res();
  if(t>=0){while(cur<n-1&&t>=starts[cur+1])cur++;load(cur+1);load(cur+2);if(cur>1&&ready[cur-2]){ready[cur-2].close();ready[cur-2]=null}
   const lt=t-starts[cur],p=Math.min(1,lt/(bufs[cur].duration+pad));g.fillStyle="#000";g.fillRect(0,0,W,H);
   if(lt<.4&&cur>0&&ready[cur-1]){draw(cur-1,1,1);draw(cur,p,lt/.4)}else draw(cur,p,1);
   if(SET.subs){g.font="bold 34px sans-serif";g.textAlign="center";const L=wrap(g,S.scenes[cur].text,W-160),y0=H-30-L.length*44;g.fillStyle="rgba(0,0,0,.6)";g.fillRect(60,y0-34,W-120,L.length*44+20);g.fillStyle="#fff";L.forEach((l,k)=>g.fillText(l,W/2,y0+k*44))}
   setProg(t/total);status(`Render: ${fmt(t)} / ${fmt(total)} (kadr ${cur+1}/${n})`)}
  requestAnimationFrame(tick)};tick()});
 await sleep(400);rec.stop();await stopped;stream.getTracks().forEach(t=>t.stop());try{wl&&wl.release()}catch{}
 Object.values(ready).forEach(b=>b&&b.close());
 if(CANCEL)return status("Render to'xtatildi");
 OUT=new Blob(chunks,{type:mime.split(";")[0]});OUTEXT=mime.includes("mp4")?"mp4":"webm";
 const v=$("#vid");v.src=URL.createObjectURL(OUT);v.style.display="block";setProg(0);status(`✅ Video tayyor (${(OUT.size/1048576).toFixed(1)} MB). Eksport bosqichiga o'ting`)});

/* ---------- Step 5: export ---------- */
async function writeBlob(blob,dir,path){const FS=P.Filesystem;
 if(!FS){const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=path.split("/").pop();a.click();return null}
 const CH=3*1024*1024;let uri;
 for(let o=0;o<blob.size;o+=CH){const b64=await new Promise((res,rej)=>{const f=new FileReader();f.onload=()=>res(f.result.split(",")[1]);f.onerror=rej;f.readAsDataURL(blob.slice(o,o+CH))});
  if(o===0){uri=(await FS.writeFile({path,data:b64,directory:dir,recursive:true})).uri}else await FS.appendFile({path,data:b64,directory:dir});
  status(`Yozilmoqda ${Math.min(100,Math.round((o+CH)/blob.size*100))}%`)}
 return uri}
const fname=()=>`VideoGen/${(S.title||"video").replace(/[^\w\u0400-\u04FF]+/g,"_").slice(0,40)}.${OUTEXT}`;
$("#save").onclick=()=>run(async()=>{if(!OUT)throw new Error("Avval video yig'ing (Montaj)");let u;
 try{u=await writeBlob(OUT,"DOCUMENTS",fname())}catch{u=await writeBlob(OUT,"EXTERNAL",fname())}
 $("#einfo").textContent=u?"Saqlandi: "+u:"Yuklab olindi";status("✅ Saqlandi")});
$("#share").onclick=()=>run(async()=>{if(!OUT)throw new Error("Avval video yig'ing (Montaj)");
 const u=await writeBlob(OUT,"CACHE",fname());if(P.Share&&u)await P.Share.share({title:S.title,url:u,dialogTitle:"Videoni ulashish"});status("✅")});

/* ---------- Step 6: SEO ---------- */
const cp=t=>navigator.clipboard.writeText(t).then(()=>status("📋 Nusxalandi"));
function drawSeo(){const s=S.seo;if(!s){$("#seo").innerHTML="";return}
 const blocks=[["Sarlavhalar",s.titles.join("\n")],["Tavsif",s.description],["Teglar",s.tags.join(", ")],["Hashtaglar",s.hashtags.join(" ")],["Thumbnail g'oyasi",s.thumbnail]];
 $("#seo").innerHTML=blocks.map(([h,t],i)=>`<div class="seo"><b>${h}</b>\n${t}</div><button class="b g" data-c="${i}">Nusxalash</button>`).join("");$("#seo").blocks=blocks}
$("#seo").onclick=e=>{if(e.target.dataset.c)cp($("#seo").blocks[e.target.dataset.c][1])};
$("#genSeo").onclick=()=>run(async()=>{status("SEO yozilmoqda…");const txt=S.scenes.map(s=>s.text).join(" ").slice(0,3000);
 S.seo=await genJSON(`YouTube SEO mutaxassisi sifatida ${LANGS[S.lang][0]} tilida yoz. Video: "${S.title}". Mazmun: ${txt}. Faqat JSON: {"titles":["5 ta sarlavha (60 belgigacha)"],"description":"chaptersiz, 1-2 abzats + kalit so'zlar","tags":["15 ta teg"],"hashtags":["3 ta"],"thumbnail":"thumbnail uchun qisqa g'oya va 3-4 so'zli matn"}`);
 saveS();drawSeo();status("✅ SEO tayyor")});

/* ---------- Settings ---------- */
function drawSettings(){$("#keys").value=SET.keys.join("\n");$("#m1").value=SET.textModel;$("#m2").value=SET.imgModel;$("#m3").value=SET.ttsModel;
 $("#kst").textContent=SET.keys.map((k,i)=>{const s=Pool.st[k]||{};return `Key #${i+1} …${k.slice(-4)}: ${s.dead?"❌ yaroqsiz":(s.until||0)>Date.now()?"⏳ limitda":"✅"}`}).join("\n")}
$("#saveSet").onclick=()=>{SET.keys=[...new Set($("#keys").value.split(/[\s,]+/).filter(k=>k.length>20))];SET.textModel=$("#m1").value.trim();SET.imgModel=$("#m2").value.trim();SET.ttsModel=$("#m3").value.trim();Pool.st={};saveSet();drawSettings();status(`✅ ${SET.keys.length} ta key saqlandi`)};
$("#reset").onclick=async()=>{if(!confirm("Barcha loyiha o'chirilsinmi? (keylar qoladi)"))return;S=Object.assign(S,{topic:"",scenes:[],title:"",seo:null});saveS();await DB.clear();await loadHave();$("#topic").value="";OUT=null;go(0)};

/* ---------- init ---------- */
initTopic();loadHave().then(()=>{drawSeo();go(0)});
